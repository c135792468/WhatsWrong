package com.example.a69591.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class symptomsActivity extends AppCompatActivity {
    ListView listView;
    ArrayList<String> myList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_symptoms);
        listView = (ListView) findViewById(R.id.list_view);
        ArrayList<String> arrayList = new ArrayList<>();
        if (getIntent().hasExtra("get")) {
            myList = (ArrayList<String>) getIntent().getSerializableExtra("get");
        }
        for (int i=0; i<myList.size(); i++) {
            arrayList.add(myList.get(i));
        }
        ArrayAdapter arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, arrayList);
        listView.setAdapter(arrayAdapter);
        /*
        // if there is a key name "box1"
        if (getIntent().hasExtra("box1")) {
            //declare a text view
            TextView box1 = (TextView) findViewById(R.id.box1);
            //get the value of the key 'box1'
            String tv1 = getIntent().getExtras().getString("box1");
            //set text view equal to the value
            box1.setText(tv1);
        }
        if (getIntent().hasExtra("box2")) {
            TextView box2 = (TextView) findViewById(R.id.box2);
            String tv2 = getIntent().getExtras().getString("box2");
            box2.setText(tv2);
        }
        if (getIntent().hasExtra("box3")) {
            TextView box3 = (TextView) findViewById(R.id.box3);
            String tv3 = getIntent().getExtras().getString("box3");
            box3.setText(tv3);
        }
        if (getIntent().hasExtra("box4")) {
            TextView box4 = (TextView) findViewById(R.id.box4);
            String tv4 = getIntent().getExtras().getString("box4");
            box4.setText(tv4);
        }
        if (getIntent().hasExtra("box5")) {
            TextView box5 = (TextView) findViewById(R.id.box5);
            String tv5 = getIntent().getExtras().getString("box5");
            box5.setText(tv5);
        } */
/*
        if (getIntent().hasExtra("get")) {
            TextView name = (TextView) findViewById(R.id.symptoms);
            ArrayList<String> myList = (ArrayList<String>) getIntent().getSerializableExtra("get");
            //String sy = getIntent().getExtras().getString("get");
            name.setText(myList.get(0));
        } */

    }
}
